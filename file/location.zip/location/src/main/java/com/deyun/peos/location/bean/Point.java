package com.deyun.peos.location.bean;


import lombok.Data;

@Data
public class Point {
    private String CardID;
    private String isSOS;
    private String XLocation;
    private String YLocation;
    private String ZLocation;
    private String state;

    public Point() {
    }

    ;

    public Point(String CardID) {
        this.CardID = CardID;
    }
}
