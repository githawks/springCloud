package com.deyun.peos.location.mq;

import com.deyun.peos.location.bean.Acceptor;
import net.sf.json.JSONObject;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jms.*;

/**
 * @author yuyan
 * @create 2018-08-28 16:09
 **/
public class Topic_Producer {

    private static final Logger _logger = LoggerFactory.getLogger(Topic_Producer.class);

    public void sendMessage(Acceptor acceptor) {

        // public void sendMessage(String msg){
        try {
            // 创建连接工厂
//			ActiveMQConnectionFactory connFactory = new ActiveMQConnectionFactory("user", "user","tcp://117.186.120.166:61616");
            ActiveMQConnectionFactory connFactory = new ActiveMQConnectionFactory("user", "user", "tcp://118.24.102.83:61616");
            connFactory.setMaxThreadPoolSize(10);

            // 连接到JMS提供者
            Connection conn = connFactory.createConnection();
            // conn.setClientID("producer1");
            conn.start();

            // 事务性会话，自动确认消息
            Session session = conn.createSession(true, Session.AUTO_ACKNOWLEDGE);
            // 消息的目的地
            Destination destination = session.createTopic("topic1");
            // 消息生产者
            MessageProducer producer = session.createProducer(destination);
            // producer.setDeliveryMode(DeliveryMode.PERSISTENT); //持久化

            // //文本消息
            // TextMessage textMessage = session.createTextMessage("这是文本消息");
            // producer.send(textMessage);

            _logger.info("***发送定位消息：" + acceptor.toString()); // 创建一条消息，当然，消息的类型有很多，如文字，字节，对象等,可以通过session.create..方法来创建出来
            JSONObject acceptorJson = JSONObject.fromObject(acceptor);
            TextMessage textMsg = session.createTextMessage(acceptorJson.toString());
            _logger.info("**送的定位消息 JSONObject 化：" + textMsg.toString());

            // 键值对消息
//			MapMessage mapMessage = session.createMapMessage();
//			mapMessage.setString("reqDesc", textMsg.toString());
            producer.send(textMsg);
            _logger.info("发送消息成功");


            // 流消息
            // StreamMessage streamMessage = session.createStreamMessage();
            // streamMessage.writeString("这是流消息");
            // producer.send(streamMessage);
            //
            // //字节消息
            // String s = "BytesMessage字节消息";
            // BytesMessage bytesMessage = session.createBytesMessage();
            // bytesMessage.writeBytes(s.getBytes());
            // producer.send(bytesMessage);
            //
            // //对象消息
            // User user = new User("obj_info", "对象消息"); //User对象必须实现Serializable接口
            // ObjectMessage objectMessage = session.createObjectMessage();
            // objectMessage.setObject(user);
            // producer.send(objectMessage);

            session.commit(); // 提交会话，该条消息会进入"queue"队列，生产者也完成了历史使命
            producer.close();
            session.close();
            conn.close();
            // 在事务性会话中，只有commit之后，消息才会真正到达目的地
        } catch (Exception e) {
            e.printStackTrace();

        }

    }

}
