package com.deyun.peos.location.bean;


import java.io.Serializable;
import java.util.Objects;

public class Acceptor implements Serializable {

    private static final long serialVersionUID = 1L;

    private String id;      //发射器ID
    private String time;    // 时间
    private String rngid;   //区域名称
    private String layId;   //层编号
    private String seq;     //包序
    private short sos;      //报警
    private String x;
    private String y;
    private String z;
    private String vbat;  //电量
    private String range; //标签与最近基站的距离值，形如 433，单位 cm 

    private String vx;    //矢量速率
    private String vy;
    private String vz;
    private String ipv4;   //ip地址
    private String peovid; //基站ID
    private String spd;    //标量速率


    public Acceptor() {
    }

    ;

    public Acceptor(String id) {
        this.id = id;
    }

    public Acceptor(String id,
                    String time,
                    String rngid,
                    String layId,
                    String seq,
                    short sos,
                    String x, String y, String z,
                    String vbat,
                    String range,
                    String vx, String vy, String vz,
                    String ipv4,
                    String peovid,
                    String spd) {
        this.id = id;
        this.time = time;
        this.rngid = rngid;
        this.layId = layId;
        this.seq = seq;
        this.sos = sos;
        this.x = x;
        this.y = y;
        this.z = z;
        this.vbat = vbat;
        this.range = range;
        this.vx = vx;
        this.vy = vy;
        this.vz = vz;
        this.ipv4 = ipv4;
        this.peovid = peovid;
        this.spd = spd;
    }


    public String getSpd() {
        return spd;
    }

    public void setSpd(String spd) {
        this.spd = spd;
    }

    public String getPeovid() {
        return peovid;
    }

    public void setPeovid(String peovid) {
        this.peovid = peovid;
    }

    public String getIpv4() {
        return ipv4;
    }

    public void setIpv4(String ipv4) {
        this.ipv4 = ipv4;
    }

    public String getRange() {
        return range;
    }

    public void setRange(String range) {
        this.range = range;
    }

    public String getVx() {
        return vx;
    }

    public void setVx(String vx) {
        this.vx = vx;
    }

    public String getVy() {
        return vy;
    }

    public void setVy(String vy) {
        this.vy = vy;
    }

    public String getVz() {
        return vz;
    }

    public void setVz(String vz) {
        this.vz = vz;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getRngid() {
        return rngid;
    }

    public void setRngid(String rngid) {
        this.rngid = rngid;
    }

    public String getLayId() {
        return layId;
    }

    public void setLayId(String layId) {
        this.layId = layId;
    }

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq;
    }

    public short getSos() {
        return sos;
    }

    public void setSos(short sos) {
        this.sos = sos;
    }

    public String getX() {
        return x;
    }

    public void setX(String x) {
        this.x = x;
    }

    public String getY() {
        return y;
    }

    public void setY(String y) {
        this.y = y;
    }

    public String getZ() {
        return z;
    }

    public void setZ(String z) {
        this.z = z;
    }

    public String getVbat() {
        return vbat;
    }

    public void setVbat(String vbat) {
        this.vbat = vbat;
    }

    @Override
    public String toString() {
        return "Acceptor{" +
                "id='" + id + '\'' +
                ", time='" + time + '\'' +
                ", rngid='" + rngid + '\'' +
                ", layId='" + layId + '\'' +
                ", seq='" + seq + '\'' +
                ", sos=" + sos +
                ", x='" + x + '\'' +
                ", y='" + y + '\'' +
                ", z='" + z + '\'' +
                ", vbat='" + vbat + '\'' +
                ", range='" + range + '\'' +
                ", vx='" + vx + '\'' +
                ", vy='" + vy + '\'' +
                ", vz='" + vz + '\'' +
                ", ipv4='" + ipv4 + '\'' +
                ", peovid='" + peovid + '\'' +
                ", spd='" + spd + '\'' +
                '}';
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Acceptor acceptor = (Acceptor) o;
        return Objects.equals(id, acceptor.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
