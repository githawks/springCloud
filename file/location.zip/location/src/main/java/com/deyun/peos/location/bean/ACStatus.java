package com.deyun.peos.location.bean;

import lombok.Data;

@Data
public class ACStatus {

    private String time;       // 时间
    private String rcdnum;     // 后续记录数
    private String totalnum;   // 总记录数
    String[] deviceIDs;       // 多个设备ID
    String[] layid;           // 层编号
    String[] devnum;           // 设备数目

}
