package com.deyun.peos.location.util;


import com.deyun.peos.location.bean.Acceptor;
import com.deyun.peos.location.services.ProducerService;
import lombok.extern.slf4j.Slf4j;
import org.apache.activemq.command.ActiveMQQueue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.jms.Destination;

@Component
@Slf4j
public class ProducerUtil {

    @Autowired
    ProducerService producerService;

    private static final Destination TOPIC = new ActiveMQQueue("topic");
    private static final Destination POINT = new ActiveMQQueue("point");

    public void sendMessage(Acceptor acceptor) {
        log.info("发送消息" + acceptor.toString());
        producerService.sendMessage(TOPIC, acceptor);
    }

    public void sendPoint(String point) {
        log.info("发送定位消息" + point);
        producerService.sendPoint(POINT, point);
    }

}
