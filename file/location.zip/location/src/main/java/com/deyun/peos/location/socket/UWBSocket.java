package com.deyun.peos.location.socket;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.activemq.command.ActiveMQQueue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.jms.core.JmsMessagingTemplate;

import com.deyun.peos.location.bean.ACStatus;
import com.deyun.peos.location.bean.Acceptor;
import com.deyun.peos.location.bean.Point;

import net.sf.json.JSONObject;

@ComponentScan
public class UWBSocket extends Thread {

    private static final Logger _logger = LoggerFactory.getLogger(UWBSocket.class);

    private DatagramSocket datagramSocket;
    private int port = 8090;
    private final int MAX_LENGTH = 1024;

    private static final String DISPLAY = "display";
    private static final String STATUS2 = "status2";
    private static final String WARNING = "warning";
    private static final String STATUS1 = "status1";
    private static final String SUMMARY = "summary";

    private Map<String, Acceptor> acceptorMap = new ConcurrentHashMap<String, Acceptor>();
    private Map<String, Point> pointMap = new ConcurrentHashMap<String, Point>();
    private Map<String, List> ptListMap = new ConcurrentHashMap<String, List>();
    private List<Point> pointsList = new ArrayList<Point>();
    private JmsMessagingTemplate jmsTemplate;

    public UWBSocket(int port) {
        this.port = port;
    }

    @Override
    public void run() {
        this.jmsTemplate = BeanContext.getApplicationContext().getBean(JmsMessagingTemplate.class);

        try {
            init();
            while (!this.isInterrupted()) {
                byte[] buffer = new byte[MAX_LENGTH];
                DatagramPacket datagramPacket = new DatagramPacket(buffer, MAX_LENGTH);
                datagramSocket.receive(datagramPacket);
                String request = new String(datagramPacket.getData(), 0, datagramPacket.getLength(), "UTF-8");
                if (!request.equals("") && request != null)
                    messageHandle(request);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void messageHandle(String request) {
        _logger.info("************messageHandle 发送的协议：" + request);
        String[] message = request.split(":");
        String headerType = message[0];
        String playLoadsXX = request.substring(request.indexOf(":") + 1, request.length());
        String[] playLoads = playLoadsXX.split(",");

        switch (headerType) {
            case DISPLAY:
                requestDisPlay(playLoads);
                break;
            case WARNING:
                requestWaring(playLoads);
                break;
            case STATUS1:
                requestStatus1(playLoads);
                break;
            case STATUS2:
                requestStatus2(playLoads);
                break;
            case SUMMARY:
                requestSummary(playLoads);
                break;
        }

    }

    /**
     * 标签或基站状态 Status1
     *
     * @param playLoads
     */
    private void requestStatus1(String[] playLoads) {
        Acceptor acceptor;

        String flag = playLoads[1];
        String id = playLoads[2];
        String time = playLoads[3];

        acceptor = getAcceptor(id);
        acceptor.setTime(time);

        if (flag.equals("TAG")) {
            String vbat = playLoads[4];
            String layId = playLoads[5];
            String vx = playLoads[6];
            String vy = playLoads[7];
            String vz = playLoads[8];

            acceptor.setVbat(vbat);
            acceptor.setLayId(layId);
            acceptor.setVx(vx);
            acceptor.setVy(vy);
            acceptor.setVz(vz);

        } else if (flag.equals("ANC")) {
            String ipv4 = playLoads[4];
            acceptor.setIpv4(ipv4);
        }
        _logger.info(acceptor.toString());
        acceptorMap.put(id, acceptor);
    }

    /**
     * 报文的状态2
     *
     * @param playLoads
     */
    private void requestStatus2(String[] playLoads) {
        Acceptor acceptor;
        String id = playLoads[1];
        String seq = playLoads[2];
        String time = playLoads[3];
        String peovid = playLoads[4];
        String range = playLoads[5];

        acceptor = getAcceptor(id);

        acceptor.setSeq(seq);
        acceptor.setTime(time);
        acceptor.setRange(range);
        acceptor.setPeovid(peovid);

        _logger.info(acceptor.toString());
        acceptorMap.put(id, acceptor);
    }

    /**
     * 标签离线统计
     *
     * @param playLoads
     */
    private void requestSummary(String[] playLoads) {
        ACStatus acstatus = new ACStatus();
        String sosType = playLoads[1];
        acstatus.setTime(playLoads[2]);

        // summary: [LEN] , RGNTAGN , [TIMESTAMP] , [RCDNUM] , [LAYID1] : [DEVNUM1] ,
        // [LAYID2]:[DE VNUM2]
        // summary: 49 , RGNTAGN , 2017-05-25 15:19:54.906 , 1 , 0 : 3
        if (sosType.equals("RGNTAGN")) { // 统计层标签数量
            String rcdnum = playLoads[3];
            String[] layid = new String[playLoads.length - 4]; // 层编号
            String[] devnum = new String[playLoads.length - 4]; // 设备数目

            for (int i = 0; i < playLoads.length - 4; i++) {
                String[] splitLayDV = playLoads[i + 4].split(":");
                layid[i] = splitLayDV[0];
                devnum[i] = splitLayDV[1];
            }
            acstatus.setLayid(layid);
            acstatus.setDevnum(devnum);
            acstatus.setRcdnum(rcdnum);
        }

        // summary:[LEN] , RGNTAGS , [TIMESTAMP] , [LAYID] , [RCDNUM] of [TOTALNUM] ,
        // [DEVID1] , [DEVID2] , ...
        // summary: 67 , RGNTAGS , 2017-05-25 15:19:54.906 , 0 , 3 of 3 , D208 , D20D ,
        // D214
        if (sosType.equals("RGNTAGS")) {      // 统计层标签 ID
            String layid = playLoads[3];
            String[] layids = new String[1];
            layids[0] = layid;
            acstatus.setLayid(layids);

            String[] deviceIDs = new String[playLoads.length - 5];

            String num = playLoads[4];
            String[] splitNum = num.split("of");
            String rcdnum = splitNum[0].replace(" ", ""); // RCDNUM
            String totalnum = splitNum[1].replace(" ", ""); // TOTALNUM

            acstatus.setRcdnum(rcdnum);
            acstatus.setTotalnum(totalnum);

            for (int i = 0; i < playLoads.length - 5; i++) {
                deviceIDs[i] = playLoads[i + 5];
            }
            acstatus.setDeviceIDs(deviceIDs);
        }

        // summary: [LEN], OFF_TAG, [TIMESTAMP], [RCDNUM] of [TOTALNUM],
        // [DEVID1],[DEVID2],...
        // summary: 137, OFF_TAG, 2017-05-25 16:15:53.353, 17 of 17,
        // D205,D206,D207,D209,D20A,D20B,D20C,D20E,D20F,D210,D211,D212,D213,D214,D215,D2
        // 16,D217
        if (sosType.equals("OFF_TAG") || sosType.equals("OFFANCH")) { // 标签 || 基站 离线统计
            String[] deviceIDs = new String[playLoads.length - 4];

            String num = playLoads[3];
            String[] splitNum = num.split("of");
            String rcdnum = splitNum[0].replace(" ", ""); // RCDNUM
            String totalnum = splitNum[1].replace(" ", ""); // TOTALNUM

            acstatus.setRcdnum(rcdnum);
            acstatus.setTotalnum(totalnum);

            for (int i = 0; i < playLoads.length - 4; i++) {
                deviceIDs[i] = playLoads[i + 4];
            }
            acstatus.setDeviceIDs(deviceIDs);
        }
        _logger.info(acstatus.toString());

    }

    /*****
     * 告警处理函数
     * @param playLoads
     */
    private void requestWaring(String[] playLoads) {
        Acceptor acceptor;
        String sosType = playLoads[1];
        String id = playLoads[2];
        acceptor = getAcceptor(id);

        acceptor.setTime(playLoads[3]);
        if (sosType.contains("SOS0x")) {
            acceptor.setSeq(playLoads[4]);
            // acceptor.setSos(sosType.replace("SOS0x",""));  SOS0x01
            String sos = playLoads[1];
            String subSOS = sos.substring(6, sos.length());
            acceptor.setSos(Short.parseShort(subSOS));                                //acceptor.setSos((short) 1);
            acceptorMap.put(id, acceptor);
            _logger.info("SOS告警信息：" + acceptor.toString());
//			if(id!=null && !id.equals(""))producerUtil.sendMessage(acceptor); 			// 发送给接收者

            if (id != null && !id.equals("") && pointsList.size() > 0) {
                Iterator<Point> it = pointsList.iterator();
                while (it.hasNext()) {
                    Point pointIT = it.next();
                    String ID = pointIT.getCardID();
                    if (ID.equals(id)) pointIT.setIsSOS(subSOS);          //报警信息更新
                }
                ptListMap.put("Points", pointsList);
                jmsTemplate.convertAndSend(new ActiveMQQueue("point"), JSONObject.fromObject(ptListMap).toString());
            }

        }

        if (sosType.contains("RGN")) { // 区域告警
            acceptor.setRngid(playLoads[4]);
            acceptor.setLayId(playLoads[5]);
        }

        if (sosType.contains("SPD")) { // 速率告警
            acceptor.setSpd(playLoads[4]);
        }

        if (sosType.equals("OFF_TAG")) {
            if (acceptorMap.containsKey(id))
                acceptorMap.remove(id);
            if (pointsList.size() > 0 && id != null && !id.equals("")) {
                Iterator<Point> it = pointsList.iterator();
                while (it.hasNext()) {
                    Point pointIT = it.next();
                    String ID = pointIT.getCardID();
                    if (ID.equals(id)) it.remove();
                }
                ptListMap.put("Points", pointsList);
                jmsTemplate.convertAndSend(new ActiveMQQueue("point"), JSONObject.fromObject(ptListMap).toString());
            }

        }
        _logger.info(acceptor.toString());
    }

    /*******
     * 定位处理函数
     * @param playLoads
     */

    private void requestDisPlay(String[] playLoads) {
        Acceptor acceptor;
        Point point;
        String id = playLoads[1];
        String seq = playLoads[2];
        String time = playLoads[3];
        String layId = playLoads[4];
        String x = playLoads[5];
        String y = playLoads[6];
        String z = playLoads[7];

        acceptor = getAcceptor(id);
        point = getPoint(id);

        acceptor.setSeq(seq);
        acceptor.setTime(time);
        acceptor.setLayId(layId);
        acceptor.setX(x);
        acceptor.setY(y);
        acceptor.setZ(z);
        acceptor.setSos((short) 0);

        point.setCardID(id);
        point.setIsSOS("0");
        point.setXLocation(x);
        point.setYLocation(y);
        point.setZLocation(z);
        acceptorMap.put(id, acceptor);
        if (pointsList.size() > 0) {
            Iterator<Point> it = pointsList.iterator();
            while (it.hasNext()) {
                Point pointIT = it.next();
                String ID = pointIT.getCardID();
                if (ID.equals(id)) it.remove();                                      //定位信息更新
            }
            pointsList.add(point);
        } else if (pointsList.size() == 0) {
            pointsList.add(point);
        }
        ptListMap.put("Points", pointsList);
        if (id != null && !id.equals("")) {
//			producerService.sendPoint(new ActiveMQQueue("point"),JSONObject.fromObject(ptListMap).toString());
            _logger.info("发送的集合 信息：" + pointsList.toString());
            jmsTemplate.convertAndSend(new ActiveMQQueue("point"), JSONObject.fromObject(ptListMap).toString());
        }

    }

    /**
     * 缓存信息
     *
     * @param key
     * @return
     */
    private Acceptor getAcceptor(String key) {
        return acceptorMap.containsKey(key) ? acceptorMap.get(key) : new Acceptor(key);
    }


    /**
     * 定位缓存信息
     *
     * @param key
     * @return
     */
    private Point getPoint(String key) {
        return pointMap.containsKey(key) ? pointMap.get(key) : new Point(key);
    }


    /**
     * 初始化连接
     */
    private void init() {
        try {
            datagramSocket = new DatagramSocket(port);
            System.out.println("udp服务端已经启动！");
        } catch (Exception e) {
            datagramSocket = null;
            System.out.println("udp服务端启动失败！");
            e.printStackTrace();
        }
    }


}
