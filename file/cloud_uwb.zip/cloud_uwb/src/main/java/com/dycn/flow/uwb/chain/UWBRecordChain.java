/*
 * Copyright 2019 y7
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.dycn.flow.uwb.chain;

import com.dycn.flow.snmp.cloud.common.redis.CommonRedis;
import com.dycn.flow.uwb.entity.bo.UWBChainBO;
import com.dycn.flow.uwb.entity.bo.UWBListenerBO;
import com.dycn.flow.uwb.entity.po.UwbPO;
import com.dycn.flow.uwb.utils.RedisKeyUtils;
import org.springframework.beans.BeanUtils;

import java.util.concurrent.TimeUnit;

/**
 * @author: y7
 * @date: 2019/12/3 17:07
 * @qq: 88247290
 * @wechat: 88247290
 * @phone: 13562233004
 * @email: 88247290@qq.com
 * @github: https://github.com/PayAbyss
 * @description: unknown
 */
public class UWBRecordChain implements UWBChain {


    @Override
    public boolean Handler(UWBChainBO uwbChainBO) {

        final CommonRedis commonRedis = uwbChainBO.getCommonRedis();
        final String key = uwbChainBO.getKeys().get(0);
        final UWBListenerBO uwbListenerBO = uwbChainBO.getUwbListenerBO();


        UwbPO uwbPO = new UwbPO();

        BeanUtils.copyProperties(uwbListenerBO, uwbPO);

        commonRedis.rightPush(key, uwbPO);

        //时间刷新
        commonRedis.expire(key, RedisKeyUtils.DEFAULT_CACHE_TIME, TimeUnit.DAYS);

        return true;
    }
}
