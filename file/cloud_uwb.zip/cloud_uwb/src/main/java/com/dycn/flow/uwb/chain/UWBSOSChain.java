/*
 * Copyright 2019 y7
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.dycn.flow.uwb.chain;

import com.alibaba.fastjson.JSONArray;
import com.dycn.flow.snmp.cloud.common.enums.CommonWarn;
import com.dycn.flow.snmp.cloud.common.redis.CommonRedis;
import com.dycn.flow.snmp.cloud.common.service.utils.CommonKeyUtil;
import com.dycn.flow.snmp.cloud.common.service.utils.CommonRedisTimeKeyUtil;
import com.dycn.flow.uwb.entity.bo.*;
import com.dycn.flow.uwb.ribbon.WarningService;
import com.dycn.flow.uwb.thread.WarningThread;
import com.dycn.flow.uwb.utils.RedisKeyUtils;
import com.dycn.flow.uwb.utils.WXPacketParseUtil;
import com.google.common.collect.Lists;
import org.apache.commons.lang.StringUtils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author: y7
 * @date: 2019/12/3 17:37
 * @qq: 88247290
 * @wechat: 88247290
 * @phone: 13562233004
 * @email: 88247290@qq.com
 * @github: https://github.com/PayAbyss
 * @description: 定位状态修改  >>> 区别危险区域 还是 SOS 告警
 */
public class UWBSOSChain implements UWBChain {

    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    @Override
    public boolean Handler(UWBChainBO uwbChainBO) {

        // 缓存Redis:
        final CommonRedis commonRedis = uwbChainBO.getCommonRedis();

        // 人员的定位信息:
        final UWBListenerBO uwbListenerBO = uwbChainBO.getUwbListenerBO();

        // 告警通知服务:
        final WarningService warningService = uwbChainBO.getWarningService();

        // 1.0 开启监测的危险区域: (已授权开启)
        final List<SectionBO> sectionBOS = accessSectionData(commonRedis);
        if(sectionBOS.size()>0){

            sectionBOS.forEach(sectionBO -> {

                // 查询该人员当天有无进入危险区域的记录:  例 >>> WARNING:RECORD:2020:09:14:d35248ab-ded5-4c4d-a7f4-164c1e2870eb
                String dayKey = CommonKeyUtil.DAY_WARNING.concat(CommonRedisTimeKeyUtil.getDataStr(LocalDateTime.now(),"yyyy-MM-dd").replace("-",":")).concat(":").concat(new CommonWarn().getWarnId("DANGEROUS"));
                boolean enterDangerous = WXPacketParseUtil.checkSOSBeforeStatus(commonRedis,dayKey,uwbListenerBO.getBindId(),sectionBO.getId());

                // 1.3 查询是否是允许进入人员
                final Set<SectionUserBO> allowedUsers = sectionBO.getAllowedUsers();
                final boolean present = allowedUsers.stream().anyMatch(sectionUserBO -> StringUtils.equals(sectionUserBO.getId(), uwbListenerBO.getBindId()));
                final boolean calculationSos = calculationSos(uwbListenerBO, sectionBO);            // 人员位置是否在限定的区域内
                final int inOrOut = sectionBO.getTag();                                             // 0 - 不可进入  >>>  1 - 不可离开

                // 1.4 人员 不在白名单内 + 危险区域坐标内 + 进入危险区域  >>>  SOS 进入危险区域告警
                if ( (!present)  && (calculationSos) && (inOrOut==0) ) {

                    uwbListenerBO.setSos(RedisKeyUtils.SOS_WARM);

                    // 有记录 >>> 已告过警 || 无记录 >>> 未告警
                    if(!enterDangerous){

                        // 判断告警类型 >>> 发送告警信息: 非允许人员产生告警记录 >>> 向告警服务发送该人员告警信息
                        new Thread(new WarningThread(warningService,uwbListenerBO,"DANGEROUS",true,sectionBO.getId(),sectionBO.getRegion())).start();
                    }
                }
                // 1.5 人员主动离开 >>> 危险区域 ( 有进入告警的记录 ) + 告警记录恢复日志:
                else if(  (!present)  && (!calculationSos) &&  (inOrOut==0) ){

                    // 告警恢复:
                    if(enterDangerous)
                        new Thread(new WarningThread(warningService,uwbListenerBO,"DANGEROUS",false,sectionBO.getId(),sectionBO.getRegion())).start();
                }
                // 1.6 人员 不在白名单内 + 工作区域坐标内 + 离开工作区域  >>> 工作区域离开告警
                else if( (!present) && (!calculationSos) && (inOrOut==1) ){
                    uwbListenerBO.setSos(RedisKeyUtils.SOS_WARM);
                }

            });
        }

        return true;
    }


    // 获取授权开启的区域:
    private List<SectionBO> accessSectionData(CommonRedis commonRedis) {

        List<SectionBO> sectionBOList = Lists.newArrayList();

        Object objects = commonRedis.get(RedisKeyUtils.SECTION);
        if(Objects.nonNull(objects)){

            sectionBOList = (List<SectionBO>) objects;
            sectionBOList.stream().filter(SectionBO::isEnable).collect(Collectors.toList());
        }

        return sectionBOList;
    }


    /**
     * 判断是否在区间内
     *
     * @param uwbListenerBO
     * @param sectionBO
     * @return
     */
    private boolean calculationSos(UWBListenerBO uwbListenerBO, SectionBO sectionBO) {
        return (uwbListenerBO.getX() >= sectionBO.getStartX() && uwbListenerBO.getX() <= sectionBO.getEndX()) &&
                (uwbListenerBO.getY() >= sectionBO.getStartY() && uwbListenerBO.getY() <= sectionBO.getEndY());
    }
}
