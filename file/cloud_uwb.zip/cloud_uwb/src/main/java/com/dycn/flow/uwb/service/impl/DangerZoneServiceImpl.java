package com.dycn.flow.uwb.service.impl;

import com.dycn.flow.snmp.cloud.common.redis.CommonRedis;
import com.dycn.flow.uwb.entity.bo.SectionBO;
import com.dycn.flow.uwb.service.DangerZoneService;
import com.dycn.flow.uwb.utils.RedisKeyUtils;
import com.google.common.collect.Lists;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * @ClassName DangerZoneServiceImpl
 * @Author 徐进程
 * @Data 2020/8/31 12:55
 * @Phone: 18321855042
 * @Email: 1042007757@qq.com
 * @Version 1.0
 * @Description TODO
 */
@Service
public class DangerZoneServiceImpl implements DangerZoneService {

    @Resource
    private CommonRedis commonRedis;

    @Override
    public void save(SectionBO sectionBO) {

        sectionBO.setId(UUID.randomUUID().toString());

        List<SectionBO> sectionBOList = Lists.newArrayList();
        Object data = commonRedis.get(RedisKeyUtils.SECTION);
        if(Objects.nonNull(data))
            sectionBOList = (List<SectionBO>)data;

        sectionBOList.add(sectionBO);
        commonRedis.set(RedisKeyUtils.SECTION,sectionBOList);
    }

    @Override
    public List<SectionBO> find() {

        List<SectionBO> result = Lists.newArrayList();

        Object o = commonRedis.get(RedisKeyUtils.SECTION);
        if(Objects.nonNull(o))
            result = (List<SectionBO>)o;

        return result;
    }

    @Override
    public void del(String id) {

        List<SectionBO> sectionBOList = Lists.newArrayList();

        Object data = commonRedis.get(RedisKeyUtils.SECTION);
        if(Objects.nonNull(data)){

            sectionBOList = (List<SectionBO>)data;
            sectionBOList = sectionBOList.stream().filter(sectionBO -> !sectionBO.getId().equals(id)).collect(Collectors.toList());
            commonRedis.set(RedisKeyUtils.SECTION,sectionBOList);
        }
    }

    @Override
    public void update(SectionBO section) {

        List<SectionBO> sectionBOList = Lists.newArrayList();

        Object data = commonRedis.get(RedisKeyUtils.SECTION);
        if(Objects.nonNull(data)){

            sectionBOList = (List<SectionBO>)data;
            sectionBOList = sectionBOList.stream().filter(sectionBO -> !sectionBO.getId().equals(section.getId())).collect(Collectors.toList());
            sectionBOList.add(section);
            commonRedis.set(RedisKeyUtils.SECTION,sectionBOList);
        }

    }

}
