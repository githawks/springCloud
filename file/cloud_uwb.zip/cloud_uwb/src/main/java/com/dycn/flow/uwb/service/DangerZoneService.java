package com.dycn.flow.uwb.service;

import com.dycn.flow.uwb.entity.bo.SectionBO;

import java.util.List;
import java.util.Set;

/**
 * @ClassName DangerZoneService
 * @Author 徐进程
 * @Data 2020/8/31 12:54
 * @Description TODO
 */
public interface DangerZoneService {

    void save(SectionBO sectionBO);

    List<SectionBO> find();

    void del(String id);

    void update(SectionBO sectionBO);

}
