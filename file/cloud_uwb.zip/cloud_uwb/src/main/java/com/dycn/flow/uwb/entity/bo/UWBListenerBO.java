/*
 * Copyright 2019 y7
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.dycn.flow.uwb.entity.bo;

import com.dycn.flow.snmp.cloud.common.bo.BO;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

/**
 * @author: y7
 * @date: 2019/12/3 14:45
 * @qq: 88247290
 * @wechat: 88247290
 * @phone: 13562233004
 * @email: 88247290@qq.com
 * @github: https://github.com/PayAbyss
 * @description: unknown
 */
@Data
public class UWBListenerBO implements BO {

    private static final long serialVersionUID = 1160940804649828610L;

    /**
     * 标签Id
     */
    private String id;

    /**
     * 卡号ID
     */
    private String cardId;

    /**
     * 告警
     */
    private int sos;

    /**
     * x 坐标
     */
    private double x;

    /**
     * y 坐标
     */
    private double y;

    /**
     * z 坐标
     */
    private double z;

    /**
     * 数据类型
     */
    @JsonIgnore
    private String objType;

    /**
     * 标签所属项目
     */
    @JsonIgnore
    private String projectId;

    /**
     *  标签所属地图
     */
    private String mapId;

    /**
     * 位置时间
     */
    @JsonIgnore
    private Long time;

    /**
     * 表示电量
     */
    private int volt;

    /**
     * 表示位置上报周期
     */
    @JsonIgnore
    private int period;

    /**
     * 表示序号
     */
    @JsonIgnore
    private int sequence;

    /**
     * 绑定id
     */
    @JsonIgnore
    private String bindId;

    /**
     * 人员名称
     */
    private String nickname;

    /**
     * 职位ID
     */
    private String dutyId;

    /**
     * 职位
     */
    private String duty;


    /**
     * 机构ID
     */
    private String orgId;

    /**
     * 机构
     */
    private String org;

    /**
     * 绑定类型
     */
    @JsonIgnore
    private String bindType;

    /**
     * 联系电话
     */
    private String phone;

}
