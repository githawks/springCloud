/*
 * Copyright 2019 y7
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.dycn.flow.uwb.chain;

import com.dycn.flow.snmp.cloud.common.redis.CommonRedis;
import com.dycn.flow.snmp.cloud.common.service.PushService;
import com.dycn.flow.uwb.entity.bo.UWBChainBO;
import com.dycn.flow.uwb.ribbon.WarningService;
import com.dycn.flow.uwb.utils.RedisKeyUtils;
import com.google.common.collect.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.List;

/**
 * @author: y7
 * @date: 2019/12/3 17:12
 * @qq: 88247290
 * @wechat: 88247290
 * @phone: 13562233004
 * @email: 88247290@qq.com
 * @github: https://github.com/PayAbyss
 * @description: unknown
 */
public class UWBChainContext implements UWBChain {

    private static final List<UWBChain> UWB_CHAINS = Lists.newArrayList();

    private CommonRedis commonRedis;
    private WarningService warningService;

    private PushService pushService;

    public UWBChainContext(CommonRedis commonRedis,WarningService warningService){
        this.commonRedis = commonRedis;
        this.warningService = warningService;
        init();
    }

    public void init() {
        UWB_CHAINS.add(new UWBSOSChain());
        UWB_CHAINS.add(new UWBLeaveChain());
        // UWB_CHAINS.add(new UWBRecordChain());
    }

    @Override
    public boolean Handler(UWBChainBO uwbChainBO) {

        uwbChainBO.setWarningService(warningService);
        uwbChainBO.setCommonRedis(commonRedis);
        uwbChainBO.setKeys(RedisKeyUtils.getRedisKey(uwbChainBO.getUwbListenerBO().getId()));

        try {

            UWB_CHAINS.forEach(uwbChain -> {

                final boolean handler = uwbChain.Handler(uwbChainBO);
                if (!handler)
                    throw new RuntimeException();

            });

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

        return true;
    }
}
