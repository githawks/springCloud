/*
 * Copyright 2019 y7
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.dycn.flow.uwb.entity.bo;

import com.dycn.flow.snmp.cloud.common.po.CommonRedisPO;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.Set;

/**
 * @author: y7
 * @date: 2019/12/3 17:46
 * @qq: 88247290
 * @wechat: 88247290
 * @phone: 13562233004
 * @email: 88247290@qq.com
 * @github: https://github.com/PayAbyss
 * @description: 危险区域
 */
@Data
@ApiModel(value ="SectionBO")
public class SectionBO extends CommonRedisPO {

    @ApiModelProperty(value = "id")
    private String id;

    @ApiModelProperty(value = "图片位置X轴")
    private double picX;

    @ApiModelProperty(value = "图片位置Y轴")
    private double picY;

    @ApiModelProperty(value = "样例图起始X轴")
    private double exSX;

    @ApiModelProperty(value = "样例图起始Y轴")
    private double exSY;

    @ApiModelProperty(value = "样例图结束X轴")
    private double exEX;

    @ApiModelProperty(value = "样例图结束X轴")
    private double exEY;

    @ApiModelProperty(value = "实际坐标起始X轴")
    private double startX;

    @ApiModelProperty(value = "实际坐标结束X轴")
    private double endX;

    @ApiModelProperty(value = "实际坐标起始Y轴")
    private double startY;

    @ApiModelProperty(value = "实际坐标结束Y轴")
    private double endY;

    @ApiModelProperty(value = "区域名称")
    private String region;

    @ApiModelProperty(value = "是否开启  true 开启 false不开启")
    private boolean enable;

    @ApiModelProperty(value = "0 进 1 出")
    private int tag;

    @ApiModelProperty(value = "投用时间")
    private String inUseTime;

    @ApiModelProperty(value = "建立时间")
    private String establishTime;

    private Set<SectionUserBO> allowedUsers;
}
