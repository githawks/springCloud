/*
 * Copyright 2019 y7
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.dycn.flow.uwb.listener;

import com.alibaba.fastjson.JSONArray;
import com.dycn.flow.snmp.cloud.common.redis.CommonRedis;
import com.dycn.flow.uwb.chain.UWBChainContext;
import com.dycn.flow.uwb.entity.bo.UWBChainBO;
import com.dycn.flow.uwb.entity.bo.UWBListenerBO;
import com.dycn.flow.uwb.pool.WebSocket;
import com.dycn.flow.uwb.ribbon.WarningService;
import com.dycn.flow.uwb.service.IAssetService;
import com.dycn.flow.uwb.service.ICardService;
import com.dycn.flow.uwb.service.UserService;
import com.dycn.flow.uwb.utils.WXPacketParseUtil;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.DatagramPacket;
import io.netty.channel.socket.nio.NioDatagramChannel;
import io.netty.util.CharsetUtil;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author: y7
 * @date: 2019/12/3 14:44
 * @qq: 88247290
 * @wechat: 88247290
 * @phone: 13562233004
 * @email: 88247290@qq.com
 * @github: https://github.com/PayAbyss
 * @description: unknown
 */
@Slf4j
public class WXUWBListener implements UWBListener {

    private int port;

    private UserService userService;

    private ICardService cardService;

    private IAssetService assetService;

    private CommonRedis commonRedis;

    private WarningService warningService;

    private UWBChainContext uwbChainContext;

    private static ConcurrentHashMap totalMap;


    private long delay;

    private long initialDelay;

    // 执行次数:
    private int times = 0;

    public WXUWBListener(int port, CommonRedis commonRedis, WarningService warningService,
                         ConcurrentHashMap<String, UWBListenerBO> locationMap,
                         ConcurrentHashMap<String, LocalDateTime> tagExpireMap,
                         UserService userService, ICardService cardService,
                         IAssetService assetService, UWBChainContext uwbChainContext,
                         long initialDelay, long delay) {

        // 所有数据:
        this.totalMap = new ConcurrentHashMap();

        // 定位和过期:
        totalMap.put("location",locationMap);
        totalMap.put("tagExpire",tagExpireMap);

        this.port = port;
        this.warningService = warningService;
        this.userService = userService;
        this.cardService = cardService;
        this.assetService = assetService;
        this.uwbChainContext = uwbChainContext;
        this.initialDelay = initialDelay;
        this.delay = delay;
        WXPacketParseUtil.initUtil(totalMap,userService, cardService, assetService,commonRedis,warningService);
    }

    @Override
    public void run() {

        // 2m 定时发送定位信息:
        initTimer();

        log.info("WXUWBListener:[{}]","************ run ****************");
        try {

            // Netty 主从多线程模型: 监听端口
            EventLoopGroup group = new NioEventLoopGroup();
            Bootstrap bootstrap = new Bootstrap();
            bootstrap.group(group)
                    .channel(NioDatagramChannel.class)
                    .option(ChannelOption.SO_BROADCAST, true)
                    .handler(new ChannelInitializer<Channel>() {
                        @Override
                        protected void initChannel(Channel channel) throws Exception {
                            ChannelPipeline channelPipeline = channel.pipeline();
                            channelPipeline.addLast(new ChannelHandler());

                        }
                    });
            bootstrap.bind(port).sync().channel().closeFuture().await();

        } catch (InterruptedException e) {
            if (log.isDebugEnabled())
                e.printStackTrace();
            log.error("WXUWBListener start failed:[{}]", e.getMessage());
        }
    }


    private class ChannelHandler extends SimpleChannelInboundHandler<DatagramPacket> {

        @Override
        protected void channelRead0(ChannelHandlerContext channelHandlerContext, DatagramPacket datagramPacket) throws Exception {

            String val = datagramPacket.content().toString(CharsetUtil.UTF_8);
            log.info("channelRead0:[{}]",val);

         //   final ByteBuf byteBuf = datagramPacket.copy().content();
         //   String val = ByteBufUtil.hexDump(byteBuf);
            final String[] startWith = val.split(":");

            int index = val.indexOf(":");
            String msg = val.substring(index+1, val.length());

            UWBListenerBO uwbListenerBO = new UWBListenerBO();
            switch (startWith[0].trim()) {

                case "display":
                    uwbListenerBO = WXPacketParseUtil.parseDisPlay(msg.trim().split(","));
                    uwbChainContext.Handler(new UWBChainBO(uwbListenerBO));

                    log.info("display:channelRead0:[{}]",( (ConcurrentHashMap<String,UWBListenerBO>) totalMap.get("location") ));
                    WXPacketParseUtil.checkAndSave(uwbListenerBO,"_tag");
                    break;

                case "warning":
                    String[] warning = msg.trim().split(",");
                    if (warning[1].contains("SOS0x"))
                        WXPacketParseUtil.parseSOS(warning);

                    if (warning[1].equals("OFF_TAG"))
                        WXPacketParseUtil.parseTagDown(warning);
                    break;

                case "status1":
                    String[] status1 = msg.trim().split(",");
                    if (status1[1].trim().equals("TAG"))
                        WXPacketParseUtil.parseTagStatus(status1);
                    break;

                default:
                    return;
            }

        }
    }



    // 初始化定时器:
    public void initTimer(){

        // 定时器:
        final Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {

                final Collection<UWBListenerBO> values =  ( (ConcurrentHashMap<String,UWBListenerBO>) totalMap.get("location") ).values();

                try {

                    Map map = new HashMap();
                    map.put("position", values);
                    WebSocket.sendInfo(JSONArray.toJSONString(map));

                    // 定时16秒执行一次清除过期标签:
                    times++;
                    times = (times == 30)?0:times;
                    if(times==0){

                        log.info("tagExpireMap:times:[{}]", totalMap.get("tagExpire"));
                        WXPacketParseUtil.checkExpireTime("_tag");
                        WXPacketParseUtil.checkExpireTime("_sos");
                    }

                } catch (IOException e) {
                    log.error("WXUWBListener sendInfo failed:[{}]", values.toString());
                }
            }
        }, initialDelay, delay);

    }

}
