package com.dycn.flow.uwb.entity.dto;

import com.baomidou.mybatisplus.annotation.TableField;
import com.dycn.flow.snmp.cloud.common.dto.BaseDTO;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;

/**
 * @ClassName UserDto
 * @Author 徐进程
 * @Data 2020/8/27 17:09
 * @Phone: 18321855042
 * @Email: 1042007757@qq.com
 * @Version 1.0
 * @Description
 */
@EqualsAndHashCode(callSuper = true)
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserDTO extends BaseDTO {

    private static final long serialVersionUID = -188509039678485755L;

    @ApiModelProperty(value = "id")
    private String id;

    @ApiModelProperty(value = "标识卡ID")
    private String typeId;

    @NotBlank(message = "名称不能为空")
    @ApiModelProperty(value = "标识卡名称", required = true)
    private String name;

    @ApiModelProperty(value = "标识卡号", hidden = true)
    private String num;

    @ApiModelProperty(value = "绑定类型 10000 人员,10001 机械,10002 物资,10003 未绑定", hidden = true)
    private String bindType;

    @ApiModelProperty(value = "刷脸状态:  刷脸 true   未刷脸 false")
    private boolean faceState;


    @ApiModelProperty(value = "机构ID", hidden = true)
    private String organizationId;

    @ApiModelProperty(value = "机构", hidden = true)
    private String organizationName;

    @ApiModelProperty(value = "职位ID", hidden = true)
    private String dutyId;

    @ApiModelProperty(value = "职位", hidden = true)
    private String dutyName;

}
