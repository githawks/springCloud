package com.dycn.flow.uwb.controller;

import com.dycn.flow.snmp.cloud.common.redis.CommonRedis;
import com.dycn.flow.snmp.cloud.common.result.Result;
import com.dycn.flow.uwb.entity.bo.SectionBO;
import com.dycn.flow.uwb.service.DangerZoneService;
import com.dycn.flow.uwb.utils.RedisKeyUtils;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @ClassName DangerZoneController
 * @Author 徐进程
 * @Data 2020/8/31 11:39
 * @Phone: 18321855042
 * @Email: 1042007757@qq.com
 * @Version 1.0
 * @Description 危险区域
 */
@RestController
@RequestMapping("/api/zone")
public class DangerZoneController {

    @Autowired
    private DangerZoneService dangerZoneService;

    @ApiOperation(value = "新增危险区域")
    @ApiImplicitParam(name = "sectionBO", value = "危险区域", required = true, dataType = "SectionBO")
    @PostMapping("save")
    public Result<String> save(@RequestBody SectionBO sectionBO){

        dangerZoneService.save(sectionBO);
        return Result.success("200:新增危险区域成功!");
    }

    @ApiOperation(value = "查看所有危险区域")
    @GetMapping("find")
    public Result<List<SectionBO>> find(){

        List<SectionBO> results = dangerZoneService.find();
        return Result.success(results);
    }


    @ApiOperation(value = "禁/启用危险区域")
    @ApiImplicitParam(name = "sectionBO", value = "危险区域", required = true, dataType = "SectionBO")
    @PutMapping("update")
    public Result<String> update(@RequestBody SectionBO sectionBO){

        dangerZoneService.update(sectionBO);
        return Result.success("禁/启用危险区域成功!");
    }


    @ApiOperation(value = "删除危险区域")
    @ApiImplicitParam(name = "id", value = "危险区域ID", required = true, dataType = "String")
    @DeleteMapping("del/{id}")
    public Result<String> del(@PathVariable("id") String id){

        dangerZoneService.del(id);
        return Result.success("200:删除危险区域成功!");
    }





    @Resource
    CommonRedis commonRedis;

    @GetMapping("findLists")
    public Result<String> findLists(){

        Object o = commonRedis.get(RedisKeyUtils.PRESENT);
        return Result.success(o.toString());
    }


}
