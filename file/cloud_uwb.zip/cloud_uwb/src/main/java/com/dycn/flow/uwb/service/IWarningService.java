package com.dycn.flow.uwb.service;

import com.dycn.flow.uwb.entity.bo.WarningBO;

import java.util.List;

/**
 * @author 徐进程
 * @since 2020-03-05
 */
public interface IWarningService {

    List<WarningBO> list();

    List<WarningBO> allLike(String msg);

    void update(WarningBO warningBO);

}
