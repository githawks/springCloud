/*
 * Copyright 2019 y7
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.dycn.flow.uwb.chain;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.dycn.flow.snmp.cloud.common.redis.CommonRedis;
import com.dycn.flow.uwb.entity.bo.LeaveSectionBO;
import com.dycn.flow.uwb.entity.bo.UWBChainBO;
import com.dycn.flow.uwb.entity.bo.UWBListenerBO;
import com.dycn.flow.uwb.entity.dto.FaceAtPresentDTO;
import com.dycn.flow.uwb.utils.RedisKeyUtils;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author: y7
 * @date: 2019/12/3 17:37
 * @qq: 88247290
 * @wechat: 88247290
 * @phone: 13562233004
 * @email: 88247290@qq.com
 * @github: https://github.com/PayAbyss
 * @description: unknown
 */
@Slf4j
public class UWBLeaveChain implements UWBChain {

    // 离开区域:
    private static Map<String,LeaveSectionBO> leaveMap = new HashMap();

    // 初始化离场区域
    public UWBLeaveChain(){
        leaveMap.put("life",new LeaveSectionBO(280,284,66,75.21));
        leaveMap.put("door",new LeaveSectionBO(241,264.01,105,111));
    }

    @Override
    public boolean Handler(UWBChainBO uwbChainBO) {

        List<FaceAtPresentDTO> atPresentList = Lists.newArrayList();

        final CommonRedis commonRedis = uwbChainBO.getCommonRedis();

        final UWBListenerBO uwbListenerBO = uwbChainBO.getUwbListenerBO();

        String userId = uwbListenerBO.getBindId();

        // 检测是否在离开区域内:
        boolean inArea = calculationLeaveArea(uwbListenerBO);
        log.info("UWBLeaveChain:inArea:[{}]","是否在离开区域: "+inArea);

        String dataStr = commonRedis.getStr(RedisKeyUtils.PRESENT);
        if( StringUtils.isNotEmpty(dataStr) && inArea){

            getSosCode(commonRedis,dataStr,"filterAtPresent",userId);
        }

        return true;
    }

    /**
     * 判断是否在离场区域内
     * @param uwbListenerBO
     * @return
     */
    private boolean calculationLeaveArea(UWBListenerBO uwbListenerBO) {

        boolean inArea = false;
        double x = uwbListenerBO.getX();
        double y = uwbListenerBO.getY();

        for (Map.Entry<String, LeaveSectionBO> entry : leaveMap.entrySet()) {

            LeaveSectionBO leaveSectionBO = entry.getValue();
            inArea = (x >= leaveSectionBO.getStartX() && x <= leaveSectionBO.getEndX()) && (y >= leaveSectionBO.getStartY() && y <= leaveSectionBO.getEndY());
            if(inArea)
                return true;
        }

        return false;
    }


    /**
     * 在场人员数据处理
     * @param dataStr       在场人员刷脸记录
     * @param method        操作方法
     * @return
     */
    public static Integer getSosCode(CommonRedis commonRedis,String dataStr,String method,String userId){

        // 所有人员的在场记录:
        List<FaceAtPresentDTO> atPresentList = Lists.newArrayList();
        atPresentList = JSONObject.parseArray(dataStr, FaceAtPresentDTO.class);
        if(atPresentList.size()>0){

            switch (method){

                // 是否刷脸入场:
                case "notInPort":
                    log.info("UWBLeaveChain:atPresentList:[{}]","刷脸入场人员: "+atPresentList);
                    boolean anyMatch = atPresentList.stream().anyMatch(faceAtPresentDTO -> faceAtPresentDTO.getId().equals(userId));
                    log.info("UWBLeaveChain:inArea:[{}]","是否刷脸入场: "+anyMatch);
                    return anyMatch?RedisKeyUtils.NORMAL:RedisKeyUtils.TEMPORARY_CARD;

                // 过滤在场人员信息:
                case "filterAtPresent":
                    atPresentList.stream().filter(faceAtPresentDTO -> !faceAtPresentDTO.getId().equals(userId)).collect(Collectors.toList());
                    commonRedis.setStr(RedisKeyUtils.PRESENT, JSONArray.toJSON(atPresentList).toString());
                    return 0;
            }
        }

        log.info("UWBLeaveChain:atPresentList:[{}]","在场人员数据处理: "+atPresentList);
        return RedisKeyUtils.TEMPORARY_CARD;
    }


}
