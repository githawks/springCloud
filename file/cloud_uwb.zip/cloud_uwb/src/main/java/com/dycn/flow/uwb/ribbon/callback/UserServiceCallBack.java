package com.dycn.flow.uwb.ribbon.callback;

import com.dycn.flow.uwb.entity.dto.UserDTO;
import com.dycn.flow.uwb.service.UserService;
import org.springframework.stereotype.Component;

/**
 * @ClassName UserServiceCallBack
 * @Author 徐进程
 * @Data 2019/7/16 16:02
 * @Phone: 18321855042
 * @Email: 1042007757@qq.com
 * @Version 1.0
 * @Description TODO
 */
@Component
public class UserServiceCallBack implements UserService {

    @Override
    public String queryUserByCardId(String card) {

        UserDTO userDTO = new UserDTO();
        userDTO.setName("服务熔断调用失败");
        return userDTO.toString();
    }


}
