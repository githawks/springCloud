package com.dycn.flow.uwb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * @ClassName UwbServer
 * @Author 徐进程
 * @Data 2020/8/26 15:48
 * @Phone: 18321855042
 * @Email: 1042007757@qq.com
 * @Version 1.0
 * @Description TODO
 */
@EnableEurekaClient
@EnableFeignClients
@SpringBootApplication
public class UwbServer {


    public static void main(String[] args) {
        SpringApplication.run(UwbServer.class, args);

    }


}
