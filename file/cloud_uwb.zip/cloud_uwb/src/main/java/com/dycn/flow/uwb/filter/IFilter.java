package com.dycn.flow.uwb.filter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @Description:
 * @Author: xjc
 * @Date: Create in 2018/7/24 15:22
 */
//@Component
//@WebFilter("/*")
public class IFilter implements Filter, Ordered {

    private static final Logger _logger = LoggerFactory.getLogger(IFilter.class);

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {

        HttpServletRequest request= (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;

        if(request.getMethod()=="OPTIONS"){

            response.setStatus(200);
            _logger.info("************************** request.getMethod()==\"OPTIONS\" "+ (request.getMethod()=="OPTIONS") +"************************");

        }
        else if(request.getMethod().equals("OPTIONS")){

            response.setStatus(200);
            response.setHeader("Access-Control-Allow-Origin", "*");
            response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE,PUT");
            response.setHeader("Access-Control-Max-Age", "3600");
            response.setHeader("Access-Control-Allow-Headers", "*");

            _logger.info("*************************** request.getMethod().equals(\"OPTIONS\"): "+ (request.getMethod().equals("OPTIONS")) + "*********************");

        }

        else {

            response.setHeader("Access-Control-Allow-Origin", "*");
            response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE,PUT");
            response.setHeader("Access-Control-Max-Age", "3600");
            response.setHeader("Access-Control-Allow-Headers", "*");
            servletResponse.setCharacterEncoding("utf-8");
            servletRequest.setCharacterEncoding("UTF-8");

            filterChain.doFilter(servletRequest, servletResponse);

            _logger.info("***************************   非 OPTIONS 请求  **************************");

        }

        _logger.info("getRequestURI ："+ ((HttpServletRequest) servletRequest).getRequestURI() + "  参数值： " +request.getParameter("license"));
        _logger.info("IFilter => 开始执行 doFilter(servletRequest,servletResponse,filterChain) ->{}"+request.getMethod());
        _logger.info("IFilter => 执行结束 doFilter(servletRequest,servletResponse,filterChain) ->{}");


    }

    @Override
    public void destroy() {

    }

    @Override
    public int getOrder() {
        return 1;
    }
}
