package com.dycn.flow.uwb.service.impl;

import com.dycn.flow.uwb.service.IAssetService;
import org.springframework.stereotype.Service;

/**
 * @ClassName IAssetServiceImpl
 * @Author 徐进程
 * @Data 2020/8/27 16:20
 * @Phone: 18321855042
 * @Email: 1042007757@qq.com
 * @Version 1.0
 * @Description TODO
 */
@Service
public class AssetServiceImpl implements IAssetService {

}
