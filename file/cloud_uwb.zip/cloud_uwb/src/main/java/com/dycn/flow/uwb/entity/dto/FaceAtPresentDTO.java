package com.dycn.flow.uwb.entity.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName FaceAtPresentDTO
 * @Author 徐进程
 * @Data 2020/9/4 13:23
 * @Phone: 18321855042
 * @Email: 1042007757@qq.com
 * @Version 1.0
 * @Description 人员在场数据
 */
@Data
public class FaceAtPresentDTO {

    @ApiModelProperty(value = "设备唯一标识")
    private String deviceKey;

    @ApiModelProperty(value = "人员ID")
    private String id;

    @ApiModelProperty(value = "人员名称")
    private String name;

    @ApiModelProperty(value = "单位ID")
    private String organizationId;

    @ApiModelProperty(value = "单位名称")
    private String organizationName;

    @ApiModelProperty(value = "职位ID")
    private String dutyId;

    @ApiModelProperty(value = "职位名称")
    private String dutyName;

    @ApiModelProperty(value = "IP")
    private String ip;

    @ApiModelProperty(value = "离开时间")
    private String time;

    @ApiModelProperty(value = "in/out")
    private String event;

    @ApiModelProperty(value = "在场时长")
    private String timeLong;

    @ApiModelProperty(value = "识别类型")
    private String type;

    @ApiModelProperty(value = "识别地点")
    private String location;

    @ApiModelProperty(value = "入场时间: 正常刷脸进入时间")
    private String validInTime;

}
