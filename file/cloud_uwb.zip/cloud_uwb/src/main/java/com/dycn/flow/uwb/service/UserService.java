package com.dycn.flow.uwb.service;

import com.dycn.flow.uwb.entity.dto.UserDTO;
import com.dycn.flow.uwb.ribbon.callback.UserServiceCallBack;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * @ClassName UserService
 * @Author 徐进程
 * @Data 2019/7/16 16:02
 * @Description TODO
 */
@Component
@FeignClient(url="http://localhost:8076", name = "user-provider",path = "/api/user",fallback = UserServiceCallBack.class)
public interface UserService {

    @GetMapping("queryUserByCardId/{card}")
    String queryUserByCardId(@PathVariable("card") String card);

}
