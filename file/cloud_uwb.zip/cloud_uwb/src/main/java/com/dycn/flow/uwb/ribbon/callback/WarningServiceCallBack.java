package com.dycn.flow.uwb.ribbon.callback;

import com.dycn.flow.snmp.cloud.common.bo.WarningRecordBO;
import com.dycn.flow.uwb.ribbon.WarningService;
import org.springframework.stereotype.Component;

/**
 * @ClassName UserServiceCallBack
 * @Author 徐进程
 * @Data 2019/7/16 16:02
 * @Phone: 18321855042
 * @Email: 1042007757@qq.com
 * @Version 1.0
 * @Description TODO
 */
@Component
public class WarningServiceCallBack implements WarningService {

    @Override
    public String findAndSave(WarningRecordBO warningRecordBO) {
        return "{\"result\": 0,\"success\":false}";
    }

}
