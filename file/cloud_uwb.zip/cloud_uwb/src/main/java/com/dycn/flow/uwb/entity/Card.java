package com.dycn.flow.uwb.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @ClassName Card
 * @Author 徐进程
 * @Data 2020/8/27 13:35
 * @Phone: 18321855042
 * @Email: 1042007757@qq.com
 * @Version 1.0
 * @Description 定位标识卡
 */
@Data
@NoArgsConstructor
@TableName("t_card")
@ApiModel(value ="Card")
public class Card extends Model<Card> {

    private static final long serialVersionUID = 1L;

    @TableId(type = IdType.UUID)
    @ApiModelProperty(value = "ID")
    @TableField("id")
    private String id;

    @ApiModelProperty(value = "标识卡名称")
    @TableField("name")
    private String name;

    @ApiModelProperty(value = "标识卡号")
    @TableField("num")
    private String num;

    @ApiModelProperty(value = "绑定类型  10000 人员,10001 机械,10002 物资,10003 未绑定")
    @TableField("bind_type")
    private Integer bindType;

}
