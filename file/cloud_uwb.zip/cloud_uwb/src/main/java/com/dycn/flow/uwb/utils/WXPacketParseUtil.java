/*
 * Copyright 2019 y7
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.dycn.flow.uwb.utils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.dycn.flow.snmp.cloud.common.enums.CommonWarn;
import com.dycn.flow.snmp.cloud.common.redis.CommonRedis;
import com.dycn.flow.snmp.cloud.common.service.utils.CommonKeyUtil;
import com.dycn.flow.snmp.cloud.common.service.utils.CommonRedisTimeKeyUtil;
import com.dycn.flow.uwb.chain.UWBLeaveChain;
import com.dycn.flow.uwb.entity.bo.UWBListenerBO;
import com.dycn.flow.uwb.entity.bo.WarningBO;
import com.dycn.flow.uwb.entity.dto.CardDTO;
import com.dycn.flow.uwb.entity.dto.UserDTO;
import com.dycn.flow.uwb.entity.enums.BindTypeEnum;
import com.dycn.flow.uwb.ribbon.WarningService;
import com.dycn.flow.uwb.service.IAssetService;
import com.dycn.flow.uwb.service.ICardService;
import com.dycn.flow.uwb.service.UserService;
import com.dycn.flow.uwb.thread.WarningThread;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author: y7
 * @date: 2019/12/3 15:22
 * @qq: 88247290
 * @wechat: 88247290
 * @phone: 13562233004
 * @email: 88247290@qq.com
 * @github: https://github.com/PayAbyss
 * @description: unknown
 */
@Slf4j
public final class WXPacketParseUtil {

    private static CommonRedis commonRedis;
    private static UserService userService;
    private static ICardService iCardService;
    private static IAssetService assetService;
    private static WarningService warningService;

    private static ConcurrentHashMap totalMap;
    // private static ConcurrentHashMap<String, UWBListenerBO> concurrentHashMap;
    // private static ConcurrentHashMap<String, LocalDateTime> tagExpireMap;

    // 64,D208,1872,2017-05-25 14:29:22.138,0,1.57,-14.30,1.50
    public static UWBListenerBO parseDisPlay(String[] fields) {

        String id = fields[1];
        id = id.substring(0,1).equals("0")?id.substring(1,id.length()):id;

        final UWBListenerBO uwbListenerBO = getUwbListenerBO(id);
        uwbListenerBO.setId(id);

        setBOMessage(uwbListenerBO);

        uwbListenerBO.setX(Double.parseDouble(fields[5]));
        uwbListenerBO.setY(Double.parseDouble(fields[6]));
        uwbListenerBO.setZ(Double.parseDouble(fields[7]));

        return uwbListenerBO;
    }


    public static void initUtil(ConcurrentHashMap totalMap,
                                UserService userService, ICardService iCardService,
                                IAssetService assetService,CommonRedis commonRedis,WarningService warningService) {

        WXPacketParseUtil.totalMap = totalMap;

        WXPacketParseUtil.warningService = warningService;
        WXPacketParseUtil.userService = userService;
        WXPacketParseUtil.iCardService = iCardService;
        WXPacketParseUtil.assetService = assetService;
        WXPacketParseUtil.commonRedis = commonRedis;
    }

    // 定位信息:
    private static UWBListenerBO getUwbListenerBO(String id) {
        return ( (ConcurrentHashMap<String,UWBListenerBO>) totalMap.get("location") ).getOrDefault(id, new UWBListenerBO());
    }

    // 识别 SOS 告警信息:
    public static void parseSOS(String[] fields) {

        String id = fields[2];
        id = id.substring(0,1).equals("0")?id.substring(1,id.length()):id;

        final UWBListenerBO uwbListenerBO = getUwbListenerBO(id);
        log.info("getUwbListenerBO:[{}]",uwbListenerBO.toString());

        uwbListenerBO.setId(id);

        setBOMessage(uwbListenerBO);
        log.info("parseSOS:[{}]",uwbListenerBO.toString());
        log.info("parseSOS:concurrentHashMap:[{}]", totalMap.get("location"));

        // SOS 更新定位标签信息: 覆盖其他告警 优先 SOS告警
        checkAndSave(uwbListenerBO,"_sos");

        // SOS区域告警:
        //uwbListenerBO.setSos(RedisKeyUtils.REGION);
        //if (uwbListenerBO.getSos() == RedisKeyUtils.REGION)
        //    return uwbListenerBO;

        //String sos = fields[1].replace("SOS0x", "").trim();
        //uwbListenerBO.setSos(Integer.parseInt(sos));
    }

    public static void parseTagDown(String[] fields) {

        String id = fields[2];
        ( (ConcurrentHashMap<String,UWBListenerBO>)totalMap.get("location") ).remove(id);
    }

    public static void parseTagStatus(String[] fields) {

        String id = fields[2];

        final UWBListenerBO uwbListenerBO = getUwbListenerBO(id);
        if (Objects.isNull(uwbListenerBO.getId()))
            return;

        uwbListenerBO.setVolt(Integer.parseInt(fields[4]));
    }


    private static void setBOMessage(UWBListenerBO uwbListenerBO) {

        final CardDTO cardDTO = iCardService.findByNum(uwbListenerBO.getId());
        System.out.println("标识卡号: " + uwbListenerBO.getId()+" 分配: " + cardDTO );

        String dutyId = "";                String orgId = "";
        String duty = "未分配";            String org = "未分配";
        String nickname = "未分配";        String phone = "非人员";
        String bindType = "未绑定";
        String cardId = cardDTO.getId();
        String bindId = cardDTO.getNum();
        Integer sos = RedisKeyUtils.TEMPORARY_CARD;              // 默认临时卡

        // 存在标识卡:
        boolean noCard = Objects.isNull(cardDTO.getId());
        if(!noCard){

            BindTypeEnum typeEnum = BindTypeEnum.getByCode(cardDTO.getBindType());
            bindType = typeEnum.getMessage();
            switch (typeEnum) {

                case PERSON:
                    String result = JSONObject.parseObject(userService.queryUserByCardId(cardId)).toString();
                    boolean unbindUser = Objects.isNull(JSONObject.parseObject(result).get("data"));
                    if(!unbindUser){

                        result = JSONObject.parseObject(result).get("data").toString();
                        final UserDTO user =  JSONObject.parseObject(result, UserDTO.class);
                        log.info("setBOMessage:user:[{}]",user);

                        if (Objects.nonNull(user)) {

                            // 人员是否刷脸入场:
                            sos = checkSosStatus(bindId,user.getId());
                            log.info("setBOMessage:concurrentHashMap:[{}]",totalMap.get("location"));
                            log.info("setBOMessage:checkSosStatus:[{}]",sos);
                            dutyId = user.getDutyId();
                            duty = user.getDutyName();
                            orgId = user.getOrganizationId();
                            org = user.getOrganizationName();
                            nickname = user.getName();
                            bindId = user.getId();
                        }
                    }
                    break;

           // 其它类型定位信息:
           /* case MECHANICS:
                final MechanicsDTO mechanicsDTO = (MechanicsDTO) mechanicsService.get(bindId).getData();

                if (Objects.nonNull(mechanicsDTO)) {
                    org = mechanicsDTO.getOrg();
                    nickname = mechanicsDTO.getLabel();
                }
                break;
            case MATERIAL:
                final MaterielDTO materielDTO1 = (MaterielDTO) materielService.get(bindId).getData();
                if (Objects.nonNull(materielDTO1)) {
                    nickname = materielDTO1.getLabel();
                }
                break;*/
            }
        }

        uwbListenerBO.setCardId(cardId);
        uwbListenerBO.setSos(sos);
        uwbListenerBO.setNickname(nickname);
        uwbListenerBO.setOrgId(orgId);
        uwbListenerBO.setOrg(org);
        uwbListenerBO.setDutyId(dutyId);
        uwbListenerBO.setDuty(duty);
        uwbListenerBO.setPhone(phone);
        uwbListenerBO.setBindId(bindId);
        uwbListenerBO.setBindType(bindType);
    }

    // 是否存在其他的告警状态: ( 优先返回其他状态的告警, 否则返回默认的 临时卡或者 刷脸告警)
    private static Integer checkSosStatus(String tag,String userId) {

        UWBListenerBO uwbListenerBO = ( (ConcurrentHashMap<String,UWBListenerBO>) totalMap.get("location") ).get(tag);
        if(Objects.nonNull(uwbListenerBO)){

            log.info("setBOMessage:checkSosStatus:nonNull:[{}]",Objects.nonNull(uwbListenerBO));
            log.info("setBOMessage:checkSosStatus:nonNull:[{}]",uwbListenerBO);

            return uwbListenerBO.getSos();

        }else {

            // 不存在告警信息: 该人员是否当天刷脸进入
            String dataStr = commonRedis.getStr(RedisKeyUtils.PRESENT);
            log.info("setBOMessage:checkSosStatus:nonNull:getStr:[{}]",dataStr);

            if( StringUtils.isNotEmpty(dataStr) )
                return UWBLeaveChain.getSosCode(commonRedis,dataStr,"notInPort",userId);
        }

        return RedisKeyUtils.TEMPORARY_CARD;
    }


    /**
     * 监测SOS手动告警
     * @param uwbListenerBO 定位信息
     * @param type          告警类型
     */
    public static void checkAndSave(UWBListenerBO uwbListenerBO,String type) {

        boolean contains = checkContains(uwbListenerBO.getId(),type);

        switch (type){

            // 1.SOS 告警标签:
            case "_sos":

                // 1.1 初始化过期标签:
                if( !contains ){

                    ((ConcurrentHashMap<String,LocalDateTime>)totalMap.get("tagExpire")).putIfAbsent(uwbListenerBO.getId().concat(type),LocalDateTime.now());

                }

                // 1.2 指定SOS:
                uwbListenerBO.setSos(RedisKeyUtils.SOS_WARM);

                // 1.3 是否有SOS告警记录: 例 >>> WARNING:RECORD:2020:09:14:d0058a97-2bbc-4e2d-b842-7f3901c60cb3
                final String dayKey = CommonKeyUtil.DAY_WARNING.concat(CommonRedisTimeKeyUtil.getDataStr(LocalDateTime.now(),"yyyy-MM-dd").replace("-",":")).concat(":").concat(new CommonWarn().getWarnId("SOS"));
                boolean sosStatus = WXPacketParseUtil.checkSOSBeforeStatus(commonRedis, dayKey, uwbListenerBO.getBindId(), "");
                if(sosStatus){

                    // 向告警服务发送告警信息: (false 结束 告警)
                   // new Thread(new WarningThread(warningService,uwbListenerBO,"SOS",false,"","")).start();

                }else {

                    // 向告警服务发送告警信息: (true 开始 告警)
                    new Thread(new WarningThread(warningService,uwbListenerBO,"SOS",true,"","")).start();
                }
                break;

            // 人员定位标签: 保存标签 --> 用于过期删除
            case "_tag":
                if(!contains)
                    ((ConcurrentHashMap<String,LocalDateTime>)totalMap.get("tagExpire")).putIfAbsent(uwbListenerBO.getId().concat(type),LocalDateTime.now());
                break;
        }

        // 保存记录:
        ( (ConcurrentHashMap<String,UWBListenerBO>) totalMap.get("location") ).putIfAbsent(uwbListenerBO.getId(),uwbListenerBO);
        log.info("putIfAbsent:[{}]" , uwbListenerBO.toString());

    }


    // 是否存在标签:
    public static boolean checkContains(String tag,String type){

        boolean contains = false;
        if( ((ConcurrentHashMap<String,LocalDateTime>)totalMap.get("tagExpire")).containsKey(tag.concat(type)) )
            contains = ((ConcurrentHashMap<String,LocalDateTime>)totalMap.get("tagExpire")).containsKey(tag.concat(type));
        return contains;
    }

    // 一次筛选是否在最大范围内:
    public boolean inArea(double startX,double endY){

        boolean inArea = false;
        return inArea;
    }

    // 多边形危险区域
    public boolean dangerAreas(){

        boolean dangerous = false;

        return dangerous;
    }

    // 过期标签失效:
    public static void checkExpireTime( String type) {

        LocalDateTime now = LocalDateTime.now();
        if( ((ConcurrentHashMap<String, LocalDateTime>) totalMap.get("tagExpire")  ).size()>0){

            for(Map.Entry entry : ((ConcurrentHashMap<String, LocalDateTime>) totalMap.get("tagExpire")).entrySet()){

                // 标识卡 + 后缀 _tag / _sos :
                String tags = entry.getKey().toString();
                if(tags.contains(type)){

                    LocalDateTime before = (LocalDateTime)entry.getValue();
                    Duration duration = Duration.between(before,now);
                    long ms = duration.toMillis();

                    // 标签过期:
                    if(ms>60000)
                        ( (ConcurrentHashMap<String, LocalDateTime>) totalMap.get("tagExpire") ).remove(tags);

                    // 定位标签过期: 删除定位标签
                    if(ms>60000 && type.equals("_tag"))
                        ( (ConcurrentHashMap<String,UWBListenerBO>) totalMap.get("location") ).remove(tags.replace("_tag",""));
                }
            }
        }
    }


    // 检测当日有无进入危险区域的告警记录:
    public static boolean checkSOSBeforeStatus(CommonRedis commonRedis,String dayKey, String bindId,String sectionId) {

        boolean enterDangerousArea = false;

        List<WarningBO> records = Lists.newArrayList();

        String dataStr = commonRedis.getStr(dayKey);
        if(StringUtils.isNotEmpty(dataStr)){

            records = JSONArray.parseArray(dataStr,WarningBO.class);
            if(records.size()>0){

                // 危险区域:
                if(StringUtils.isNotEmpty(sectionId))
                    enterDangerousArea = records.stream().anyMatch(warningBO -> {
                        return Objects.isNull(warningBO.getEndTime()) && ( warningBO.getUser_id().equals(bindId) && (warningBO.getSectionId().equals(sectionId)) ) ;
                    });

                // SOS:
                if(StringUtils.isEmpty(sectionId))
                    enterDangerousArea = records.stream().anyMatch(warningBO -> {
                        return Objects.isNull(warningBO.getEndTime()) && ( warningBO.getUser_id().equals(bindId) ) ;
                    });
            }
        }

        return enterDangerousArea;
    }





}
