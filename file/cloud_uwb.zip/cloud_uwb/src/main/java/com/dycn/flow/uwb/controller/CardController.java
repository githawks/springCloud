package com.dycn.flow.uwb.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dycn.flow.snmp.cloud.common.result.Result;
import com.dycn.flow.uwb.entity.Card;
import com.dycn.flow.uwb.service.ICardService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @ClassName PortsController
 * @author 徐进程
 * @since  2020-02-09
 * @Phone: 18321855042
 * @Email: 1042007757@qq.com
 * @Version 1.0
 * @Description 定位标识卡
 */
@Slf4j
@Api("定位标识卡")
@RestController
@RequestMapping("/api/card")
public class CardController {

    private ICardService targetService;

    @Autowired
    public CardController(ICardService targetService){
        this.targetService = targetService;
    }

    @ApiOperation(value = "查询所有定位标识卡")
    @GetMapping("all")
    public Result<List<Card>> findAll(){
        List<Card> models = targetService.list();
        return Result.success(models);
    }

    @ApiOperation(value = "查询所有定位标识卡 - 绑定 - 未绑定")
    @ApiImplicitParam(name = "bind", value = " 0 - 绑定 , 1 - 未绑定", required = true, dataType = "String")
    @GetMapping("allBind/{bind}")
    public Result<List<Card>> findAllBind(@PathVariable("bind") String bind){
        List<Card> models = targetService.findAllBind(bind);
        return Result.success(models);
    }

    @ApiOperation(value = "根据ID查询定位标识卡")
    @ApiImplicitParam(name = "id", value = "定位标识卡ID", required = true, dataType = "String")
    @GetMapping("find/{id}")
    public Result<Card> find(@PathVariable("id") String id){
        Card ports = targetService.getById(id);
        if(ports==null)
           log.info("PortsController:find:[{}]","根据ID查询定位标识卡失败!");

        return Result.success(ports);
    }


    @ApiOperation(value = "新增定位标识卡")
    @ApiImplicitParam(name = "card", value = "定位标识卡", required = true, dataType = "Card")
    @PostMapping("save")
    public Result<String> save(@RequestBody Card card){

        boolean isOk = targetService.saveOrUpdate(card);
        return Result.success("新增定位标识卡: " + isOk);
    }


    @ApiOperation(value = "修改多个定位标识卡")
    @ApiImplicitParam(name = "list", value = "定位标识卡", required = true,allowMultiple = true, dataType = "Card")
    @PostMapping("updateList")
    public Result<List<Card>> updateList(@RequestBody List<Card> list){
        boolean isOk = targetService.updateBatchById(list);
        if(!isOk)
            log.info("PortsController:update:[{}]","修改多个定位标识卡失败: " +isOk);

        // 返回所有集合:
        List<Card> models = targetService.list();
        return Result.success(models);
    }

    @ApiOperation(value = "修改定位标识卡")
    @ApiImplicitParam(name = "ports", value = "定位标识卡", required = true, dataType = "Ports")
    @PostMapping("update")
    public Result<List<Card>> update(@RequestBody Card card){
        boolean isOk = targetService.updateById(card);
        if(!isOk)
           log.info("PortsController:update:[{}]","修改定位标识卡失败: " +isOk);

        // 返回所有集合:
        List<Card> models = targetService.list();
        return Result.success(models);
     }

    @ApiOperation(value = "通过 ID 删除定位标识卡")
    @ApiImplicitParam(name = "id", value = "定位标识卡ID", required = true, dataType = "String")
    @DeleteMapping("del/{id}")
    public Result<List<Card>> del(@PathVariable("id") String id){
        boolean isOk = targetService.removeById(id);

        if(!isOk)
            log.info("PortsController:del:[{}]","通过 ID 删除定位标识卡失败: " +isOk);

        // 返回所有集合:
        List<Card> models = targetService.list();
        return Result.success(models);
    }

    @ApiOperation(value = "分页 + 查询所有定位标识卡")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "pageIndex",    value = "第几页 : 默认值 1",  required = true,  dataType = "Integer"),
        @ApiImplicitParam(name = "step",         value = "第几行 : 默认值 20", required = true,  dataType = "Integer")
    })
    @GetMapping("list/{pageIndex}/{step}")
    public Result<Page> findListByPage(@PathVariable("pageIndex") int pageIndex,@PathVariable("step") int step){
        Page page = new Page(pageIndex,step);
        targetService.page(page);
        return Result.success(page);
    }


}
