package com.dycn.flow.uwb.service;

/**
 * @ClassName IAssetService
 * @Author 徐进程
 * @Data 2020/8/27 16:19
 * @Description 物资
 */
public interface IAssetService {


}
