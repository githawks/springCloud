package com.dycn.flow.uwb.entity.enums;

/**
 * @ClassName BindTypeEnum
 * @Author 徐进程
 * @Data 2020/8/27 11:57
 * @Phone: 18321855042
 * @Email: 1042007757@qq.com
 * @Version 1.0
 * @Description TODO
 */
public enum BindTypeEnum {

    PERSON(10000, "人员"),

    MECHANICS(10001, "机械"),

    MATERIAL(10002, "物资"),

    NO_BIND(1000, "未绑定");

    /**
     * 操作码
     */
    private Integer code;

    /**
     * 信息
     */
    private String message;


    BindTypeEnum(Integer code, String message) {
        this.code = code;
        this.message = message;

    }


    public Integer getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }


    public static boolean isValid(Integer value) {
        for (BindTypeEnum userTypeEnum : BindTypeEnum.values()) {
            if (userTypeEnum.getCode().intValue() == value.intValue()) {
                return true;
            }
        }
        return false;
    }


    public static BindTypeEnum getByCode(Integer code) {

        for (BindTypeEnum value : BindTypeEnum.values()) {
            if (value.getCode().intValue() == code.intValue())
                return value;
        }

        return BindTypeEnum.NO_BIND;
    }

}

