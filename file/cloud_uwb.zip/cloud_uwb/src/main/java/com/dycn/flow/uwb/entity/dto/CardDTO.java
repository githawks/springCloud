package com.dycn.flow.uwb.entity.dto;

import com.baomidou.mybatisplus.annotation.TableField;
import com.dycn.flow.snmp.cloud.common.dto.BaseDTO;
import com.dycn.flow.uwb.entity.enums.BindTypeEnum;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;

/**
 * @ClassName MaterielDTO
 * @Author 徐进程
 * @Data 2020/8/27 11:49
 * @Phone: 18321855042
 * @Email: 1042007757@qq.com
 * @Version 1.0
 * @Description 标识卡
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class CardDTO extends BaseDTO {
    private static final long serialVersionUID = -188509039678485755L;

    @ApiModelProperty(value = "标识卡ID")
    private String id;

    @ApiModelProperty(value = "标识卡名称")
    private String name;

    @NotBlank(message = "名称不能为空")
    @ApiModelProperty(value = "标识卡号")
    private String num;

    @ApiModelProperty(value = "绑定类型 10000 人员,10001 机械,10002 物资,10003 未绑定")
    private Integer bindType;

    public static class BindTypeValid {


        public static boolean isValid(Integer code) {
            for (BindTypeEnum typeEnum : BindTypeEnum.values()) {
                if (code.intValue() == typeEnum.getCode())
                    return true;
            }

            return false;
        }
    }
}
