package com.dycn.flow.uwb.entity.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dycn.flow.uwb.entity.Card;

/**
 * @ClassName CardMapper
 * @Author 徐进程
 * @Data 2020/8/27 13:42
 * @Description TODO
 */
public interface CardMapper extends BaseMapper<Card> {

}
