package com.dycn.flow.uwb.ribbon;

import com.dycn.flow.snmp.cloud.common.bo.WarningRecordBO;
import com.dycn.flow.uwb.ribbon.callback.WarningServiceCallBack;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * @ClassName UserService
 * @Author 徐进程
 * @Data 2019/7/16 16:02
 * @Description TODO
 */
@Component
@FeignClient(url="http://localhost:8811", name = "cloud-common-warning",path = "/api/warning_record",fallback = WarningServiceCallBack.class)
public interface WarningService {

    @PostMapping("findAndSave")
    String findAndSave(@RequestBody WarningRecordBO warningRecordBO);

}
