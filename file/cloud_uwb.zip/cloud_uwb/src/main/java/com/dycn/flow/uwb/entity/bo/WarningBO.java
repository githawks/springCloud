package com.dycn.flow.uwb.entity.bo;

import com.dycn.flow.snmp.cloud.common.po.CommonRedisPO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName WarningBO
 * @Author 徐进程
 * @Data 2020/9/6 22:07
 * @Phone: 18321855042
 * @Email: 1042007757@qq.com
 * @Version 1.0
 * @Description 告警记录
 */
@Data
@ApiModel("WarningBO")
public class WarningBO extends CommonRedisPO {

    @ApiModelProperty(value = "告警记录ID")
    private String id;

    @ApiModelProperty(value = "告警名称")
    private String name;

    @ApiModelProperty(value = "告警描述")
    private String description;

    @ApiModelProperty(value = "告警级别")
    private Integer level;

    @ApiModelProperty(value = "告警对象ID")
    private String user_id;

    @ApiModelProperty(value = "告警对象")
    private String user;

    @ApiModelProperty(value = "单位ID")
    private String orgId;

    @ApiModelProperty(value = "单位")
    private String org;

    @ApiModelProperty(value = "职位ID")
    private String dutyId;

    @ApiModelProperty(value = "职位")
    private String duty;

    @ApiModelProperty(value = "标识卡ID")
    private String card_id;

    @ApiModelProperty(value = "标识卡")
    private String card;

    @ApiModelProperty(value = "告警区域ID")
    private String sectionId;

    @ApiModelProperty(value = "告警区域名称")
    private String section;

    @ApiModelProperty(value = "告警时间")
    private String startTime;

    @ApiModelProperty(value = "恢复时间")
    private String endTime;

    @ApiModelProperty(value = "处理状态:  0 未处理  1 已处理")
    private Integer status;

}
