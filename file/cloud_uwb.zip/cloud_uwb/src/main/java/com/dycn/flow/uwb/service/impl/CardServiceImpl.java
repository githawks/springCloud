package com.dycn.flow.uwb.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.dycn.flow.uwb.entity.Card;
import com.dycn.flow.uwb.entity.dto.CardDTO;
import com.dycn.flow.uwb.entity.mapper.CardMapper;
import com.dycn.flow.uwb.service.ICardService;
import com.google.common.collect.Lists;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

/**
 * @ClassName CardServiceImpl
 * @Author 徐进程
 * @Data 2020/8/27 13:44
 * @Phone: 18321855042
 * @Email: 1042007757@qq.com
 * @Version 1.0
 * @Description TODO
 */
@Service
public class CardServiceImpl  extends ServiceImpl<CardMapper, Card> implements ICardService {

    @Override
    public List<Card> findAllBind(String bind) {

        // 默认查询人员绑定:
        int bindType = bind.equals("0")?10000:1000;
        List<Card> cardList = Lists.newArrayList();

        cardList = baseMapper.selectList((QueryWrapper<Card>) new QueryWrapper().eq("bind_type", bindType));
        return cardList;
    }

    @Override
    public CardDTO findByNum(String num) {

        CardDTO cardDTO = new CardDTO();
        Card card = baseMapper.selectOne((QueryWrapper<Card>) new QueryWrapper().eq("num", num));
        if (Objects.nonNull(card))
            BeanUtils.copyProperties(card,cardDTO);

        return cardDTO;
    }


}
