package com.dycn.flow.uwb.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.dycn.flow.uwb.entity.Card;
import com.dycn.flow.uwb.entity.dto.CardDTO;

import java.util.List;

/**
 * <p>
 * 账户 服务类
 * </p>
 *
 * @author 徐进程
 * @since 2020-03-05
 */
public interface ICardService extends IService<Card> {

    List<Card> findAllBind(String bind);

    CardDTO findByNum(String num);
}
