package com.dycn.flow.uwb.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * @Author: 洪福
 * @Date: 2019/7/5 20:08
 * @QQ: 88247290
 * @Wechat: 88247290
 * @Phone: 13562233004
 * @Email: 88247290@qq.com
 * @Github: https://github.com/PayAbyss
 * @Description:
 */
@Configuration
@EnableSwagger2
public class SwaggerConfiguration {

    @Bean
    public Docket createRestApi() {
        return new Docket(DocumentationType.SWAGGER_2)
                .apiInfo(apiInfo())
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.dycn.flow.uwb.controller"))
                .paths(PathSelectors.any())
                .build();
    }


    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title("上海德鋆信息科技有限公司用户信息系统接口")
                .description("OA管理系统接口")
                .termsOfServiceUrl("http://{ip}:8078")
                .contact(new Contact(
                        "徐进程",
                        "https://github.com/Xjc104",
                        "1042007757@qq.com"))
                .version("1.0")
                .build();
    }
}
