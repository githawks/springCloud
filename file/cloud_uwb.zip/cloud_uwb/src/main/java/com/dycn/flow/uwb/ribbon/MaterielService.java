package com.dycn.flow.uwb.ribbon;

import com.dycn.flow.uwb.entity.dto.CardDTO;

import java.util.List;

/**
 * @ClassName MaterielService
 * @Author 徐进程
 * @Data 2020/8/27 12:04
 * @Phone: 18321855042
 * @Email: 1042007757@qq.com
 * @Version 1.0
 * @Description 物料卡服务
 */
public interface MaterielService {

    String bind(List<CardDTO> materielDTOS);

    void clearBind(String id);

    CardDTO getBySerialNumber(String serialNumber);

}
