package com.dycn.flow.uwb.entity.bo;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @ClassName LeaveSetionBO
 * @Author 徐进程
 * @Data 2020/9/3 15:08
 * @Phone: 18321855042
 * @Email: 1042007757@qq.com
 * @Version 1.0
 * @Description 离场区域
 */

@Data
@AllArgsConstructor
public class LeaveSectionBO {

    @ApiModelProperty(value = "离场区域起始X轴")
    private double startX;

    @ApiModelProperty(value = "离场区域结束X轴")
    private double endX;

    @ApiModelProperty(value = "离场区域起始Y轴")
    private double startY;

    @ApiModelProperty(value = "离场区域结束Y轴")
    private double endY;


}
