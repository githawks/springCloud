/*
 * Copyright 2019 y7
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.dycn.flow.uwb.utils;

import com.google.common.collect.Lists;
import org.apache.commons.lang.StringUtils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * @author: y7
 * @date: 2019/12/3 16:32
 * @qq: 88247290
 * @wechat: 88247290
 * @phone: 13562233004
 * @email: 88247290@qq.com
 * @github: https://github.com/PayAbyss
 * @description: unknown
 */
public class RedisKeyUtils {

    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private static final List<String> KEYS = Lists.newArrayList();

    public static int DEFAULT_CACHE_TIME = 120000;
    private static String date = "1996-11-24";

    public static final int NORMAL = 0;             //正常
    public static final int NON_REAL_NAME  = -1;    //未经过人脸识别
    public static final int TEMPORARY_CARD = -2;    //临时卡
    public static final int REGION   = -3;          //危险区域
    public static final int SOS_WARM = -4;          //SOS告警

    private static final String PREFIX = "LOCATION";
    private static final String SPLIT = ":";

    /**
     * 人员当天在场记录 2020:08:01:atPresent
     */
    public static final String PRESENT = LocalDateTime.now().format(DATE_TIME_FORMATTER).replace("-",":").concat(":atPresent");

    /**
     * 记录
     * LOCATION:RECORD:yyyy-MM-dd:id
     */
    public static final String RECORD = PREFIX.concat(SPLIT).concat("RECORD").concat("%s").concat(SPLIT).concat("%s");

    /**
     * 告警区间
     */
    public static final String SECTION = "LOCATION:SECTION:SECTION";

    /**
     * 告警记录
     */
    public static final String WARNING_RECORD = "LOCATION:WARNING:RECORD:%s";

    /**
     * 获取记录数据
     *
     * @param id 用户id
     * @return index 0 day key  index 1 weekStatistics index 2 weekTimeStatistics
     */
    public static List<String> getRedisKey(String id) {

        LocalDateTime localDateTime = LocalDateTime.now();

        //获取当前日期 yyyy-MM-dd
        String newDate = localDateTime.format(DATE_TIME_FORMATTER);

        if (!StringUtils.equals(date, newDate)) {

            KEYS.clear();

            date = newDate;

            int day = localDateTime.getDayOfMonth();

            //获取当前是本月的第几周 7天为一周  每月自然周
            int week = day <= 7 ? 1 : day <= 14 ? 2 : day <= 21 ? 3 : 4;

            String month = date.substring(0, date.lastIndexOf("-"));

            String record = String.format(RECORD, date, id);


            KEYS.add(String.format(WARNING_RECORD, newDate));

            KEYS.add(record);


        }


        return KEYS;
    }
}
