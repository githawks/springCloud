package com.dycn.flow.uwb.controller;

import com.dycn.flow.snmp.cloud.common.result.Result;
import com.dycn.flow.uwb.entity.bo.WarningBO;
import com.dycn.flow.uwb.service.IWarningService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @ClassName PortsController
 * @author 徐进程
 * @since  2020-02-09
 * @Phone: 18321855042
 * @Email: 1042007757@qq.com
 * @Version 1.0
 * @Description 告警
 */
@Slf4j
@Api("告警")
@RestController
@RequestMapping("/api/warning")
public class WarningController {

    private IWarningService targetService;

    @Autowired
    public WarningController(IWarningService targetService){
        this.targetService = targetService;
    }

    @ApiOperation(value = "查询所有风险告警")
    @GetMapping("all")
    public Result<List<WarningBO>> findAll(){
        List<WarningBO> models = targetService.list();
        return Result.success(models);
    }


    @ApiOperation(value = "模糊查询所有风险告警")
    @ApiImplicitParam(name = "msg", value = "模糊查询内容", required = true, dataType = "String")
    @GetMapping("allLike/{msg}")
    public Result<List<WarningBO>> allLike(@PathVariable("msg") String msg){
        List<WarningBO> models = targetService.allLike(msg);
        return Result.success(models);
    }

    @ApiOperation(value = "修改风险告警")
    @ApiImplicitParam(name = "warningBO", value = "风险告警", required = true, dataType = "WarningBO")
    @PostMapping("update")
    public Result<String> update(@RequestBody WarningBO warningBO){

        targetService.update(warningBO);
        return Result.success("200:修改风险告警成功!");
     }

}
