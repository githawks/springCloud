package com.dycn.flow.uwb.utils;

/**
 * @ClassName WarningKeyUtils
 * @Author 徐进程
 * @Data 2020/9/6 22:25
 * @Phone: 18321855042
 * @Email: 1042007757@qq.com
 * @Version 1.0
 * @Description 告警类型
 */
public class WarningKeyUtils {

    public final static String key ="UWB:WARNINGS:RECORDS:ALL";

    // 告警类型: 人员风险告警
    public final static Integer PERSON_WARNS = 0;


    // 告警级别: 普通告警
    public final static Integer COMMON_LEVEL = 0;

}
