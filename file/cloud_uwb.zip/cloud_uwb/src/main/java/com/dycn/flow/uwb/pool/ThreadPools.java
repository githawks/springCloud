package com.dycn.flow.uwb.pool;

import com.dycn.flow.snmp.cloud.common.redis.CommonRedis;
import com.dycn.flow.uwb.chain.UWBChainContext;
import com.dycn.flow.uwb.ribbon.WarningService;
import com.dycn.flow.uwb.service.IAssetService;
import com.dycn.flow.uwb.service.ICardService;
import com.dycn.flow.uwb.service.UserService;
import com.dycn.flow.uwb.listener.WXUWBListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @ClassName ThreadPools
 * @Author 徐进程
 * @Data 2020/6/9 11:13
 * @Phone: 18321855042
 * @Email: 1042007757@qq.com
 * @Version 1.0
 * @Description 线程池
 */
//@Component
@Configuration
public class ThreadPools implements ApplicationRunner {

    @Resource
    private ICardService cardService;

    @Resource
    private UserService userService;

    @Resource
    private CommonRedis commonRedis;

    @Resource
    private IAssetService assetService;

    @Autowired
    private WarningService warningService;

    private ExecutorService fixedThreadPool = Executors.newFixedThreadPool(10);

    @Override
    public void run(ApplicationArguments args) throws Exception {

        fixedThreadPool.execute(

                new Thread(
                        new WXUWBListener(8090,commonRedis,warningService,new ConcurrentHashMap(),new ConcurrentHashMap(),userService, cardService, assetService, new UWBChainContext(commonRedis,warningService),
                                0, 2000)
                )
              );
    }

}
