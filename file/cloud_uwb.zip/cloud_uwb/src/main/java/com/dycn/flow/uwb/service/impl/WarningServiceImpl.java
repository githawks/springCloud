package com.dycn.flow.uwb.service.impl;

import com.dycn.flow.snmp.cloud.common.redis.CommonRedis;
import com.dycn.flow.uwb.entity.bo.WarningBO;
import com.dycn.flow.uwb.service.IWarningService;
import com.dycn.flow.uwb.utils.WarningKeyUtils;
import com.google.common.collect.Lists;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @ClassName CardServiceImpl
 * @Author 徐进程
 * @Data 2020/8/27 13:44
 * @Phone: 18321855042
 * @Email: 1042007757@qq.com
 * @Version 1.0
 * @Description TODO
 */
@Service
public class WarningServiceImpl implements IWarningService {

    @Resource
    CommonRedis commonRedis;

    @Override
    public List<WarningBO> list() {

        List<WarningBO> list = Lists.newArrayList();

        Object o = commonRedis.get(WarningKeyUtils.key);
        if( Objects.nonNull(o) )
            list = (List<WarningBO>) o;

        return list;
    }

    @Override
    public List<WarningBO> allLike(String msg) {

        List<WarningBO> list = Lists.newArrayList();

        Object o = commonRedis.get(WarningKeyUtils.key);
        if( Objects.nonNull(o) ){

            list = (List<WarningBO>) o;
            list =  list.stream().filter(
                    warningBO -> warningBO.getName().contains(msg) || warningBO.getDescription().contains(msg) || warningBO.getUser().contains(msg) || warningBO.getOrg().contains(msg)
            ).sorted(Comparator.comparing(WarningBO::getStartTime).reversed()).collect(Collectors.toList());
        }

        return list;
    }

    @Override
    public void update(WarningBO warningBO) {

        List<WarningBO> list = Lists.newArrayList();

        Object o = commonRedis.get(WarningKeyUtils.key);
        if( Objects.nonNull(o) ){

            list = (List<WarningBO>) o;
            list = list.stream().filter(warning -> !warning.getId().equals(warningBO.getId()) ).collect(Collectors.toList());
            commonRedis.set(WarningKeyUtils.key,list);
        }
    }


}
