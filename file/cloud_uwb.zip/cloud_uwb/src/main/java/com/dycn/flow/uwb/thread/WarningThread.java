package com.dycn.flow.uwb.thread;

import com.dycn.flow.snmp.cloud.common.bo.WarningRecordBO;
import com.dycn.flow.snmp.cloud.common.enums.CommonWarn;
import com.dycn.flow.uwb.entity.bo.UWBListenerBO;
import com.dycn.flow.uwb.ribbon.WarningService;
import lombok.extern.slf4j.Slf4j;

import java.util.UUID;

/**
 * @ClassName WarningThread
 * @Author 徐进程
 * @Data 2020/9/14 14:48
 * @Phone: 18321855042
 * @Email: 1042007757@qq.com
 * @Version 1.0
 * @Description 发送告警信息
 */
@Slf4j
public class WarningThread implements Runnable {

    private String type;                    // 告警处理类型  >>>>  SOS || DANGEROUS
    private boolean flag;                   // 开始 >>> 结束 告警
    private String sectionId;               // 告警区域ID
    private String section;                 // 告警区域
    private UWBListenerBO uwbListenerBO;
    private WarningService warningService;

    public WarningThread(WarningService warningService,UWBListenerBO uwbListenerBO,String type,boolean flag,String sectionId,String section){
        this.sectionId = sectionId;
        this.section = section;
        this.flag = flag;
        this.type = type;
        this.warningService = warningService;
        this.uwbListenerBO = uwbListenerBO;
    }

    @Override
    public void run() {

        switch (type){

            // SOS告警:  阀值 0  >>>>    1 告警记录  0 恢复
            case "SOS":
                warningService.findAndSave( generateWarnRecord(uwbListenerBO,"SOS",flag?1:0) );
                break;

            // 危险区域告警:  阀值 0 >>>>  1 告警记录  0 恢复
            case "DANGEROUS":
                warningService.findAndSave(generateWarnRecord(uwbListenerBO, "DANGEROUS",flag?1:0));
                break;
        }

    }

    /**
     * 生成告警对象记录
     * @param uwbListenerBO 人员定位信息
     * @param type          DANGEROUS >>> 危险区域  /  SOS >>> SOS告警
     * @return
     */
    public WarningRecordBO generateWarnRecord(UWBListenerBO uwbListenerBO,String type,double values){

        WarningRecordBO warningRecordBO = WarningRecordBO.builder()
                .id(UUID.randomUUID().toString()).values(values)
                .cardId(uwbListenerBO.getCardId()).card(uwbListenerBO.getId())
                .orgId(uwbListenerBO.getOrgId()).org(uwbListenerBO.getOrg())
                .dutyId(uwbListenerBO.getDutyId()).duty(uwbListenerBO.getDuty())
                .userId(uwbListenerBO.getBindId()).user(uwbListenerBO.getNickname())
                .wid(new CommonWarn().getWarnId(type)).section(section).sectionId(sectionId)
                .build();

        return warningRecordBO;
    }

}
